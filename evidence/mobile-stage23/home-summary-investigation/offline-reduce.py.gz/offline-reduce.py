"""Offline arithmetic on the one recorded launch. No app or test imports."""
from collections import Counter, defaultdict
import datetime
import gzip
import hashlib
import json
import re
from pathlib import Path
from zoneinfo import ZoneInfo

out=Path('/workspace/shiguang-app/evidence/mobile-stage23/home-summary-investigation')
prior=out.parent/'perf-investigation/scratch'
ledger=json.loads((out/'ledger.json').read_text())
launch=ledger['launches'][0]
def raw(name): return gzip.decompress((out/name).read_bytes())
trace=json.loads(raw('trace.json.gz'))
samples=json.loads(raw('samples.json.gz'))
workers=[json.loads(line) for line in raw('workers.jsonl.gz').splitlines()]
console=raw('console.log.gz').decode()
def rounded(x): return round(x,6)
def overlap(events,start,end):
    ranges=sorted((max(start,a),min(end,b)) for a,b in events if a<end and b>start)
    total=0
    last=start
    for a,b in ranges:
        total+=max(0,b-max(a,last)); last=max(b,last)
    return rounded(total)
gc=[(e['startMs'],e['startMs']+e['durationMs']) for e in trace['gc']]
bygroup=defaultdict(list)
for e in trace['points']: bygroup[e['group']].append(e)
zone=ZoneInfo('Asia/Shanghai')
def local(ms):
    return datetime.datetime.fromtimestamp((trace['timeOrigin']+ms)/1000, zone).isoformat()
def diff(left,right,start,end):
    a,b=left['counters'],right['counters']
    cpu={k:{v:(b[k][v]-a[k][v])/1000 for v in ('user','system')} for k in ('thread','cpu')}
    duration=end-start
    sched=(b['runtimeNs']-a['runtimeNs'])/1e6
    wait=(b['waitNs']-a['waitNs'])/1e6
    return dict(wallMs=rounded(duration),threadUserMs=cpu['thread']['user'],threadSystemMs=cpu['thread']['system'],
                mainMs=rounded(sum(cpu['thread'].values())),processUserMs=cpu['cpu']['user'],processSystemMs=cpu['cpu']['system'],
                processMs=rounded(sum(cpu['cpu'].values())),schedExecMs=rounded(sched),schedWaitMs=rounded(wait),
                schedSlices=b['slices']-a['slices'],wallLessSchedExecAndWaitMs=rounded(duration-sched-wait),
                gcEntries=[i for i,(x,y) in enumerate(gc) if x<end and y>start],
                gcUnionMs=overlap(gc,start,end))
timers={}
phases={}
for group,points in bygroup.items():
    a,b=points[0],points[-1]
    native=trace['intervals'].get(group)
    start=native['startMs'] if native else a['enterMs']
    end=start+native['elapsedMs'] if native else b['enterMs']
    data=diff(a,b,start,end)
    data.update(clock='original performance.now' if native else 'observer entry to entry',startLocal=local(start),
                endLocal=local(end),counterEnvelopeMinusWallMs=rounded((b['counters']['hi']-a['counters']['lo'])/1e6-(end-start)),
                measuredProbeUnionInWindowMs=overlap([(x['enterMs'],x['leaveMs']) for x in points],start,end),
                observerGcCallbackOverlapMs=overlap(trace['deliveries'],start,end))
    timers[group]=data
    if group not in ('setup','domain.homeSummary','adapter.homeSummary'): continue
    phases[group]=[]
    for left,right in zip(points,points[1:]):
        lower=start if left is a else left['enterMs']
        upper=end if right is b else right['enterMs']
        row=diff(left,right,lower,upper)
        phases[group].append(dict(begin=left['name'],end=right['name'],**row))

p=bygroup['adapter.homeSummary']
a,b=p[0]['counters'],p[-1]['counters']
elapsed=round(trace['intervals']['adapter.homeSummary']['elapsedMs']*1e6)
# Original clock reads are inside [a.hi, b.lo]. Every poll wholly inside these tighter
# bounds falls in the native timed interval for every possible alignment.
latest_start=b['lo']-elapsed
earliest_end=a['hi']+elapsed
inside=[(i,s) for i,s in enumerate(samples) if s['lo']>=latest_start and s['hi']<=earliest_end]
seen=defaultdict(list)
for i,s in enumerate(samples):
    for pid,runtime,wait,slices in s['threads']: seen[pid].append((i,runtime))
inside_indices={i for i,_ in inside}
active={}
confirmed=[]
possible=[]
for e in workers:
    pid=e['pid']
    if pid==trace['pid']: continue
    points=seen[pid]
    interior=[v for i,v in points if i in inside_indices]
    if interior or (e['startNs']<earliest_end and e['endNs']>latest_start): confirmed.append(e['file'])
    if points:
        first,last=points[0][0],points[-1][0]
        birth=samples[first-1]['lo'] if first else launch['startNs']
        gone=samples[last+1]['hi'] if last+1<len(samples) else launch['endNs']
        if birth<b['lo'] and gone>a['hi']: possible.append(e['file'])
    if len(interior)>1 and interior[-1]>interior[0]:
        active[e['file']]=dict(polls=len(interior),mainExecMs=rounded((interior[-1]-interior[0])/1e6))
peers=dict(whollyInsidePolls=len(inside),monitorCpuInThesePollsMs=sum(s['monitorCpuNs'] for _,s in inside)/1e6,
           confirmedDistinct=sorted(confirmed),possibleDistinct=sorted(possible),confirmedCpuIncrements=active,
           largestPeerCensusInOnePoll=max((sum(pid!=trace['pid'] for pid,*_ in s['threads']) for _,s in inside),default=0))

totals={k:int(v) for k,v in re.findall(r'^[ℹ#] (tests|pass|fail|cancelled|skipped|todo) (\d+)$',console,re.M)}
expected=launch['command'][4:]
files=[e['file'] for e in workers]
reported=re.findall(r'^✔ (tests/\S+\.test\.ts) \([\d.]+ms\)$',console,re.M)
checks=dict(all28Files=Counter(expected)==Counter(files)==Counter(reported) and len(files)==28,
            kernelChildPidsMatchWorkerExits=set(seen)=={e['pid'] for e in workers} and all(e['parent']==launch['pid'] for e in workers),
            workerExitCodesZero=all(e['code']==0 for e in workers),
            workerLifetimesBounded=all(launch['startNs']<=e['startNs']<=e['endNs']<=launch['endNs'] for e in workers),
            allNativeMuseumTimings=len(trace['intervals'])==18 and trace['passedLastAssertions'] and len(trace['matched'])==8,
            thresholds=all(v['elapsedMs']<(200 if k=='adapter.reunionPage' else 150) for k,v in trace['intervals'].items()),
            fileLevelTotals=totals=={"tests":28,"pass":28,"fail":0,"cancelled":0,"skipped":0,"todo":0},
            inputMatches=trace['input']==json.loads((prior/'input.json').read_text()),
            outputMatches=trace['adapter']==trace['domain']==json.loads((prior/'run-01-P/museum.json').read_text())['home'],
            storageMatches=trace['stored']['identical'] and trace['stored']['beforeWrites']==trace['stored']['afterWrites']==1,
            rawHashes=all(hashlib.sha256(raw(k)).hexdigest()==v['sha256'] and hashlib.sha256((out/k).read_bytes()).hexdigest()==v['gzipSha256'] for k,v in launch['raw'].items()))
result=dict(formulas=dict(wall='Native elapsed for 18 test clocks. Setup uses entry of first/last marks. Subphases use mark entry to next mark entry, clipped at native start/end.',
     cpu='End minus start counters. /proc/thread-self/schedstat run and runnable wait are nanoseconds. process.{threadCpuUsage,cpuUsage} user and system are microseconds. Native counter boundaries are adjacent to, not atomic with, clock reads.',
     gc='Union of GC performance-entry wall intervals intersected with the given window. Indexes refer to raw trace.gc. Overlap is not an additional time component.',
     residual='Wall minus Linux execution and runnable wait. Includes unmeasured non-runnable time and accounting/envelope error.',
     probes='Sum of clipped non-overlapping mark read windows. Excludes dispatch, JIT, scheduling side effects. The two photosNext opening probes fall inside the original clock.',
     peers='Only coordinator direct-child schedstat polls entirely inside the native target, bounded using its duration and outside monotonic clock brackets. In-window first-to-last increments exclude unsampled edges.'),
     checks=checks,reporterUnit='file',totals=totals,sourceCaseCount=json.loads((prior/'reconcile/cases.json').read_text())['total'],
     timers=timers,phases=phases,peers=peers,sourceInferredWorkPerSuccessfulV5Reload=dict(rawReads=1,jsonParses=1,recordChecks=5000,
       snapshotSlots=10000,nonNullSnapshots=5000,photoChecks=5000,tagRowChecks=5000),
     originalSourceGroup='core/tests and Rust do not run inside the default npm script')
(out/'measurements.json').write_text(json.dumps(result,indent=2)+'\n')
print('checks',checks)
for k in ('setup','domain.homeSummary','adapter.homeSummary'): print(k,timers[k])
print('peers',peers)
if not all(checks.values()): print('CHECK DISAGREEMENT')
